function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6m9mSg0yzma":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

